# Inventar-App - Übung Tag 3

Die Aufgaben D bis G sind im vorhandenen inventar-starter umgesetzt. Notizen zur Referenz stehen in [docs/grades-notes.md](docs/grades-notes.md); Bearbeitungsstand und Vorführanleitung in [docs/aufgaben-loesung.md](docs/aufgaben-loesung.md).

## Start

Im Verzeichnis `inventar-starter/inventar-starter` ausführen:

```powershell
docker compose up -d --build
```

- Oberfläche: http://localhost:8000/inventory
- API und Try it out: http://localhost:8000/docs
- Health: http://localhost:8000/health (200, wenn DB und MQTT erreichbar sind; sonst 503)

Die Ports 8000, 5432, 1883 und 9001 müssen frei sein. Andere Übungs-Stacks vorher bei Bedarf beenden. Die DB liegt im benannten Volume `inventory_db`. Ein normales `docker compose down` löscht die Daten nicht.

**Init-SQL:** PostgreSQL führt `db/init/*.sql` nur bei einer neuen Datenbank aus. Bei einer vorhandenen DB ohne Inventar-Schema zuerst prüfen, ob die Tabellen fehlen. Dann kann die Schema-Datei einmalig eingespielt werden:

```powershell
Get-Content -Raw db/init/010_inventory_schema.sql | docker compose exec -T db psql -v ON_ERROR_STOP=1 -U appuser -d appdb
```

Die Datei erzeugt Tabellen und Beispieldaten in einer Transaktion. Sie ist keine wiederholt ausführbare Migration. Bei bestehenden Inventar-Tabellen nicht erneut ausführen und kein Datenvolume zum Zurücksetzen löschen.

## API

| Methode | Route | Zweck |
| --- | --- | --- |
| GET/POST | /devices | Geräte auflisten/anlegen |
| GET/PUT/DELETE | /devices/{device_id} | Gerät lesen/vollständig ändern/löschen |
| GET | /assignments | Gesamte Ausleihhistorie |
| GET | /assignments/active | Aktive Ausleihen |
| POST | /assignments | Ausgeben |
| POST | /assignments/{assignment_id}/return | Zurückgeben |

Beispiel für `POST /devices`:

```json
{"serial_number":"DEMO-001","device_type_id":1,"location_id":1,"status":"ready","note":"Vorführgerät"}
```

Beispiel für `POST /assignments` (die tatsächlich zurückgegebene Geräte-ID nutzen):

```json
{"device_id":5,"person_id":1}
```

Rückgabe: `{}` oder kein Body setzt die aktuelle Zeit. Optionale Zeitangaben müssen eine Zeitzone enthalten, z. B. `2026-10-24T12:00:00+02:00`. Die Oberfläche zeigt UTC.

## Domänenregeln

- IR-01: `UNIQUE(serial_number)`; doppelte Seriennummer ergibt 409. Leerzeichen an den Rändern werden bei Eingaben entfernt; Groß-/Kleinschreibung bleibt relevant.
- IR-02: Partieller UNIQUE-Index auf `assignment(device_id) WHERE returned_at IS NULL`; zweite aktive Ausleihe ergibt auch bei parallelen Requests 409.
- IR-03: CHECK auf `returned_at >= issued_at`; ungültige Rückgabe ergibt 422.
- Fremdschlüssel verhindern ungültige Referenzen (422) und das Löschen von Geräten mit Historie (409).
- Nur einsatzbereite Geräte sind ausleihbar. Ein ausgeliehenes Gerät muss vor einer Stilllegung zurückgegeben werden. Unbekannte Geräte/Ausleihen ergeben 404, wiederholte Rückgaben 409.

## MQTT und Chat

Nach erfolgreichem DB-Commit publiziert die API mit QoS 1 auf `inventory/assignments/issued` bzw. `inventory/assignments/returned`. JSON enthält IDs und ISO-Zeitstempel. Bei einem Broker-Ausfall bleibt der DB-Vorgang gespeichert; der Fehler erscheint im API-Log. Es gibt keine dauerhafte Event-Warteschlange und keinen nachträglichen Versand. QoS 1 kann bei Wiederholungen Duplikate erzeugen.

Terminal 1 (Ereignisse):

```powershell
docker compose exec mqtt mosquitto_sub -h localhost -t 'inventory/assignments/#' -v
```

Terminal 1 (Chat empfangen):

```powershell
docker compose exec mqtt mosquitto_sub -h localhost -t 'inventory/chat/tag3' -v
```

Terminal 2 (Chat senden):

```powershell
docker compose exec mqtt mosquitto_pub -h localhost -t 'inventory/chat/tag3' -m 'Selim: Hallo aus Terminal 2'
```

`localhost` bezeichnet in diesen Befehlen den MQTT-Container. Mit lokal installiertem mosquitto funktionieren dieselben Befehle ohne `docker compose exec mqtt` über Host-Port 1883.

## Tests

Ein separater Compose-Stack ohne Host-Ports prüft Schema, CRUD, die drei Regeln, parallele Ausgabe, UI und echte MQTT-Nachrichten. Er verwendet eigene temporäre Testdaten und verändert nicht die Daten der normalen App.

```powershell
docker compose -p inventory-tests -f compose.test.yml up --build --abort-on-container-exit --exit-code-from test
docker compose -p inventory-tests -f compose.test.yml down -v
```

`down -v` ist hier ausschließlich für den isolierten Stack `inventory-tests` gedacht.

Ohne Docker (nur Vertrags-/Validierungstests):

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest -q tests/test_contract.py
```

Die Integrationstests werden ohne `RUN_INTEGRATION=1` übersprungen. Ein bestandener Offline-Test bestätigt noch keinen vollständigen DB-/MQTT-Betrieb.
