# B) Notizen zum grades-starter

Der grades-starter wurde aus dem bereitgestellten ZIP gelesen. Er bleibt unverändert und dient nur als Referenz.

## Struktur und Datenbank
- `backend/app/main.py`: FastAPI-App, Routen, Template-Aufrufe, Form-Verarbeitung und MQTT-Publish.
- `backend/app/db.py`: `get_conn()` öffnet eine psycopg-Verbindung mit `dict_row` und `autocommit=True`.
- `backend/app/models.py`: getrennte Pydantic-Modelle für Create, Update und Ausgabe, zum Beispiel `StudentCreate`, `StudentUpdate`, `Grade`.
- `db/init/001_schema.sql`: `student`, `module`, `grade`; Primärschlüssel, eindeutige Matrikelnummer und Modulnamen, Semester-CHECK (1 bis 12), Fremdschlüssel von `grade` zu `student`/`module` mit `ON DELETE CASCADE`.
- `backend/app/templates/`: Startseite, `students/index.html`, `students/edit.html`, `grades/index.html` und `grades/_list.html`.

## Formulare und Templates
`POST /students` liest Felder mit `Form(...)`, erzeugt `StudentCreate`, führt ein parametrisiertes INSERT aus und rendert die Notenseite oder leitet mit 303 weiter. `POST /students/{student_id}/edit` verarbeitet die Bearbeitung. `POST /students/{student_id}/delete` löscht einen Studierenden.

`Jinja2Templates` lädt den Template-Ordner. `TemplateResponse` erhält Template-Namen sowie Request und Daten im Context. Jinja-Schleifen erzeugen Tabellen und Dropdowns. Bei htmx liefert `POST /grades/htmx` nur `grades/_list.html`; `GET /grades/htmx` lädt die gefilterte Notenliste nach.

## CRUD-Flow
1. GET liest Datensätze mit `get_conn()` und einem Cursor.
2. Ein Formular sammelt Eingaben; FastAPI/Pydantic validieren sie.
3. INSERT/UPDATE/DELETE arbeiten mit `%s` und separaten Parameterwerten.
4. Die aktualisierte Liste oder ein Redirect wird an den Browser geschickt.

## Übertragung auf die Inventar-App
Gleicher technischer Stack: FastAPI, psycopg, Pydantic, Jinja und MQTT. Für Inventar liegen die Datenoperationen in `services.py`; `db.py` nutzt Transaktionen (`autocommit=False`), damit MQTT erst nach dem Commit gesendet wird. Die UI sammelt Formulardaten mit `FormData` und sendet JSON an dieselben Endpunkte wie Swagger `/docs`. Das ersetzt die Form-/htmx-Routen des Referenzprojekts und vermeidet doppelte Fachlogik.

Ein Start des Referenz-Stacks wurde hier nicht durchgeführt, weil die Docker-Engine nicht erreichbar ist. Für einen separaten Test können die Ports mit einem Compose-Override auf 8001/5433/1884/9002 gelegt werden, damit beide Stacks nicht dieselben Host-Ports belegen.
