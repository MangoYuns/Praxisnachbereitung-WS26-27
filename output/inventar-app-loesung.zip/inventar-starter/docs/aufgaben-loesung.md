# Bearbeitung der Aufgaben A bis H

## A und C - Ausgangspunkt und Feature-Branch
Der vorhandene Basis-Commit ist `1e71dba` (Initial Commit Tag-3 inventar-starter). Er lag beim Beginn auf `Tag-3`, nicht auf `main`. Der Arbeitsbaum war sauber. Die Lösung wurde auf `codex/inventar-app` begonnen. `main` und die vorhandene Historie wurden nicht umgeschrieben. Damit ist der in der PDF gewünschte Basis-Commit auf main hier noch nicht hergestellt. Nach gemeinsamer Prüfung kann das Team den Basisstand regulär nach main integrieren. Ein Push oder Merge wurde nicht ausgeführt.

Branch-Wechsel vorführen: `git status`, `git branch --show-current`, `git log --oneline --all --graph`. Erst nach gesicherten Änderungen den Branch wechseln, beispielsweise `git switch Tag-3` und zurück `git switch codex/inventar-app`. Die unterschiedlichen Versionen von `db/init/010_inventory_schema.sql` erklären. Ein Branch-Wechsel ändert Dateien, führt aber keine Datenbankmigration aus.

## B - Referenz
Siehe `grades-notes.md`: Struktur, Tabellen, Constraints, get_conn, Form, Jinja, htmx und CRUD-Flows sind erläutert. Im grades-starter wurde nicht entwickelt.

## D - Schema
`db/init/010_inventory_schema.sql` enthält department, person, device_type, location, device und assignment mit PK, FK, NOT NULL, UNIQUE und CHECK. Seed: zwei Abteilungen, drei Personen, drei Typen, drei Standorte, vier Geräte und zwei Ausleihen (eine aktiv, eine beendet). issued_at/returned_at sind timestamptz. Standort bezeichnet den Inventarstandort; Verfügbarkeit wird aus der aktiven Ausleihe ermittelt.

Prüfung im laufenden Stack:

```powershell
docker compose exec db psql -U appuser -d appdb -c '\dt'
docker compose exec db psql -U appuser -d appdb -c '\d device'
docker compose exec db psql -U appuser -d appdb -c '\d assignment'
docker compose exec db psql -U appuser -d appdb -c 'SELECT * FROM device;'
```

Ein Neustart allein führt Init-SQL bei vorhandenen Daten nicht noch einmal aus. Hinweise im README beachten.

## E - API und Regeln
CRUD für Geräte und die geforderten Assignment-Endpunkte stehen in `main.py`, gemeinsame Fachlogik in `services.py`, Pydantic-Modelle in `models.py`. DB-Fehler werden in 409 bzw. 422 übersetzt. Nicht vorhandene Ressourcen ergeben 404. IR-01 ist ein UNIQUE-Constraint; IR-02 ein partieller UNIQUE-Index; IR-03 ein CHECK. Diese drei Regeln gelten dadurch auch bei direktem SQL-Zugriff. `FOR UPDATE` koordiniert Ausgabe und Statusänderung sowie mehrfache Rückgaben.

In /docs testen: Gerät anlegen (201); dieselbe Seriennummer erneut anlegen (409); ausgeben (201); erneut ausgeben (409); Rückgabezeit vor Ausgabe setzen (422); gültig zurückgeben (200). Ein Geräte-Update erfolgt mit PUT und vollständigem Body. Löschen ist für ungenutzte Geräte möglich (204); bei Ausleihhistorie 409.

## F - Oberfläche
`/inventory` zeigt Typ, Standort, Status und Verfügbarkeit. Formulare erlauben Hinzufügen, Bearbeiten, Löschen, Ausgabe und Rückgabe. Das Ausgabe-Dropdown enthält nur freie und einsatzbereite Geräte. HTML-Formulare werden per FormData zu JSON und an die regulären API-Endpunkte gesendet. Fehler erscheinen in der Oberfläche. Nach Erfolg wird die Seite neu geladen. Kein htmx/CDN ist erforderlich. Jinja maskiert Benutzereingaben.

## G - MQTT
Ausgabe: `inventory/assignments/issued`; Rückgabe: `inventory/assignments/returned`. Versand nach DB-Commit mit QoS 1; kein Erfolgsereignis bei abgelehnten Requests. Nutzdaten enthalten assignment_id, device_id, person_id, issued_at, returned_at. Ein Broker-Ausfall wird geloggt; ein bereits gespeicherter Vorgang bleibt gespeichert. Dauerhaft garantierter Versand ist nicht Teil dieser Übung. Subscriber- und Zwei-Terminal-Chat-Befehle stehen im README.

## H - Vorführung
1. `docker compose up -d --build`, dann `/health`, `/docs`, `/inventory` zeigen.
2. Ein Gerät `DEMO-001` anlegen. ID aus der Antwort bzw. Liste übernehmen.
3. In der UI eine Person und das neue freie Gerät wählen, dann ausgeben.
4. Das Gerät ist jetzt ausgeliehen und fehlt im Ausgabe-Dropdown. Den Versuch einer zweiten Ausleihe in /docs zeigen: 409.
5. In der aktiven Liste zurückgeben. Das Gerät ist wieder frei. MQTT-Subscriber zeigt Ausgabe und Rückgabe.
6. Den partiellen Index im SQL, `services.issue()` und `main.create_assignment()` erläutern.
7. Im zweiten Terminal Chatnachricht senden und im ersten empfangen. Git-Graph und Branch-Unterschiede zeigen.

## Tatsächlicher Prüfstand
Die Docker-Engine war in dieser Umgebung auch nach Startversuch von Docker Desktop nicht erreichbar. Deshalb wurden Start von Referenz/App, echte PostgreSQL-Regeln, MQTT-Zustellung, Chat und die Vorführung noch nicht live bestätigt. `docker compose config --quiet` akzeptiert beide Compose-Dateien. Offline-Testergebnisse werden in der beiliegenden Lösungs-PDF und `test-ergebnis.txt` dokumentiert. Der separate Integrationstest führt den DB-/MQTT-Nachweis auf einer funktionierenden Docker-Installation aus.
