"""Echte PostgreSQL-/MQTT-Tests: RUN_INTEGRATION=1 setzen; isolierte Test-DB nutzen."""
import os
import json
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
import pytest

pytestmark = pytest.mark.skipif(os.getenv('RUN_INTEGRATION') != '1', reason='PostgreSQL/MQTT-Integration nicht aktiviert')

def test_real_database_rules_crud_parallel_issue_and_mqtt():
    import paho.mqtt.client as mqtt
    from fastapi.testclient import TestClient
    from backend.app.main import app
    from backend.app.db import get_conn
    client = TestClient(app)
    assert client.get('/health').status_code == 200
    assert client.get('/docs').status_code == 200
    received = []
    subscribed = threading.Event()
    subscriber = mqtt.Client()
    subscriber.on_connect = lambda c,u,f,rc: c.subscribe('inventory/assignments/#',qos=1)
    subscriber.on_subscribe = lambda *args: subscribed.set()
    subscriber.on_message = lambda c,u,msg: received.append((msg.topic,json.loads(msg.payload)))
    subscriber.connect(os.getenv('MQTT_HOST','mqtt'),int(os.getenv('MQTT_PORT','1883')),30)
    subscriber.loop_start()
    device_id = None
    try:
        assert subscribed.wait(5)
        with get_conn() as conn:
            person_id = conn.execute('SELECT person_id FROM person LIMIT 1').fetchone()['person_id']
            type_id = conn.execute('SELECT device_type_id FROM device_type LIMIT 1').fetchone()['device_type_id']
            location_id = conn.execute('SELECT location_id FROM location LIMIT 1').fetchone()['location_id']
        body = dict(serial_number='TEST-'+uuid.uuid4().hex,device_type_id=type_id,location_id=location_id)
        created = client.post('/devices',json=body)
        assert created.status_code == 201, created.text
        device_id = created.json()['device_id']
        assert client.post('/devices',json=body).status_code == 409  # IR-01
        assert client.get(f'/devices/{device_id}').json()['availability'] == 'frei'
        assert client.put(f'/devices/{device_id}',json={**body,'note':'Test'}).status_code == 200
        body_assignment = dict(device_id=device_id,person_id=person_id,issued_at='2026-01-01T12:00:00Z')
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: client.post('/assignments',json=body_assignment),range(2)))
        assert sorted(r.status_code for r in results) == [201,409]  # IR-02, parallel
        aid = next(r.json()['assignment_id'] for r in results if r.status_code == 201)
        assert any(a['assignment_id']==aid for a in client.get('/assignments/active').json())
        assert client.get(f'/devices/{device_id}').json()['availability'] == 'ausgeliehen'
        assert client.delete(f'/devices/{device_id}').status_code == 409
        assert client.post(f'/assignments/{aid}/return',json={'returned_at':'2025-12-31T12:00:00Z'}).status_code == 422  # IR-03
        assert client.post(f'/assignments/{aid}/return',json={'returned_at':'2026-01-02T12:00:00Z'}).status_code == 200
        assert client.post(f'/assignments/{aid}/return').status_code == 409
        assert client.get(f'/devices/{device_id}').json()['availability'] == 'frei'
        assert client.get('/inventory').status_code == 200
        # Publisher wartet auf PUBACK. Die Subscriber-Zustellung kann kurz nachlaufen.
        import time
        deadline = time.monotonic()+5
        while time.monotonic()<deadline and len([r for r in received if r[1]['assignment_id']==aid])<2:
            time.sleep(.05)
        events=[topic for topic,row in received if row['assignment_id']==aid]
        assert events.count('inventory/assignments/issued') == 1
        assert events.count('inventory/assignments/returned') == 1
        # Historie bleibt im Produkt erhalten; nur diese Testdaten werden aufgeräumt.
        with get_conn() as conn:
            conn.execute('DELETE FROM assignment WHERE device_id=%s',(device_id,))
        assert client.delete(f'/devices/{device_id}').status_code == 204
        assert client.get(f'/devices/{device_id}').status_code == 404
        device_id=None
    finally:
        subscriber.disconnect()
        subscriber.loop_stop()
        if device_id:
            with get_conn() as conn:
                conn.execute('DELETE FROM assignment WHERE device_id=%s',(device_id,))
                conn.execute('DELETE FROM device WHERE device_id=%s',(device_id,))
