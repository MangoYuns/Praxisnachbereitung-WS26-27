from datetime import datetime, timezone
from unittest.mock import patch
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from backend.app.main import app
from backend.app.models import DeviceCreate, AssignmentCreate, AssignmentReturn
from backend.app.mqtt_integration import publish_assignment

client = TestClient(app)

def test_openapi_exposes_crud_and_assignment_bodies():
    schema = client.get('/openapi.json').json()
    assert set(schema['paths']['/devices']) == {'get', 'post'}
    assert {'get', 'put', 'delete'} <= set(schema['paths']['/devices/{device_id}'])
    assert 'post' in schema['paths']['/assignments/{assignment_id}/return']
    assert 'requestBody' in schema['paths']['/assignments']['post']

@pytest.mark.parametrize('value', ['', '   '])
def test_empty_serial_rejected(value):
    with pytest.raises(ValidationError):
        DeviceCreate(serial_number=value, device_type_id=1, location_id=1)

@pytest.mark.parametrize('body', [
    {'device_id':0,'person_id':1},
    {'device_id':1,'person_id':1,'issued_at':'2026-10-24T12:00:00'},
    {'device_id':1,'person_id':1,'issued_at':'kein Datum'},
    {'device_id':1,'person_id':1,'unexpected':True},
])
def test_invalid_assignment_is_rejected_before_db(body):
    with patch('backend.app.services.get_conn') as db:
        assert client.post('/assignments',json=body).status_code == 422
        db.assert_not_called()

def test_return_requires_timezone():
    with pytest.raises(ValidationError):
        AssignmentReturn(returned_at='2026-10-24T12:00:00')

def test_mqtt_failure_does_not_undo_saved_assignment():
    row = dict(assignment_id=1, device_id=1, person_id=1,
               issued_at=datetime.now(timezone.utc), returned_at=None)
    with patch('backend.app.mqtt_integration.publish',side_effect=ConnectionError):
        publish_assignment('issued',row)

def test_inventory_escapes_user_content_and_only_offers_free_devices():
    rows = [dict(device_id=1, serial_number='<script>alert(1)</script>', device_type_id=1,
        location_id=1,device_type='Laptop', location='E', status='ready',note=None,availability='frei'),
        dict(device_id=2, serial_number='TAKEN',device_type_id=1,location_id=1,device_type='Laptop',
        location='E',status='ready',note=None,availability='ausgeliehen')]
    with patch('backend.app.services.devices',return_value=rows), \
         patch('backend.app.services.assignments',return_value=[]), \
         patch('backend.app.services.lookups',return_value=dict(device_types=[],locations=[],persons=[])):
        result = client.get('/inventory')
    assert result.status_code == 200
    assert '<script>alert(1)</script>' not in result.text
    assert '&lt;script&gt;alert(1)&lt;/script&gt;' in result.text
    assert '<option value="2">TAKEN' not in result.text
