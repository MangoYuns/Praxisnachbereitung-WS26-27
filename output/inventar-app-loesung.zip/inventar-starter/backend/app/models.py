from datetime import datetime
from typing import Annotated, Literal
from pydantic import AwareDatetime, BaseModel, ConfigDict, Field, StringConstraints

Text = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=200)]
PositiveId = Annotated[int, Field(gt=0)]

class InputModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

class DeviceCreate(InputModel):
    serial_number: Text
    device_type_id: PositiveId
    location_id: PositiveId
    status: Literal["ready", "maintenance", "retired"] = "ready"
    note: str | None = Field(default=None, max_length=2000)

class Device(DeviceCreate):
    device_id: int
    device_type: str
    location: str
    availability: Literal["frei", "ausgeliehen", "nicht verfügbar"]

class AssignmentCreate(InputModel):
    device_id: PositiveId
    person_id: PositiveId
    issued_at: AwareDatetime | None = None

class AssignmentReturn(InputModel):
    returned_at: AwareDatetime | None = None

class Assignment(BaseModel):
    assignment_id: int
    device_id: int
    person_id: int
    issued_at: datetime
    returned_at: datetime | None
    serial_number: str
    person: str
