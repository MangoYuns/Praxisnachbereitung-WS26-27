from fastapi import HTTPException
from .db import get_conn
from .models import AssignmentCreate, AssignmentReturn, DeviceCreate
from .mqtt_integration import publish_assignment

DEVICE_SELECT = """
SELECT d.*,t.name AS device_type,l.name AS location,
 CASE WHEN EXISTS (SELECT 1 FROM assignment a WHERE a.device_id=d.device_id AND a.returned_at IS NULL)
 THEN 'ausgeliehen' WHEN d.status='ready' THEN 'frei' ELSE 'nicht verfügbar' END AS availability
FROM device d JOIN device_type t USING(device_type_id) JOIN location l USING(location_id)
"""
ASSIGNMENT_SELECT = """
SELECT a.*,d.serial_number,p.first_name || ' ' || p.last_name AS person
FROM assignment a JOIN device d USING(device_id) JOIN person p USING(person_id)
"""

def devices():
    with get_conn() as conn:
        return conn.execute(DEVICE_SELECT + " ORDER BY d.device_id").fetchall()

def device(device_id):
    with get_conn() as conn:
        row = conn.execute(DEVICE_SELECT + " WHERE d.device_id=%s", (device_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Gerät nicht gefunden")
    return row

def save_device(data: DeviceCreate, device_id=None):
    values = (data.serial_number,data.device_type_id,data.location_id,data.status,data.note)
    with get_conn() as conn:
        if device_id is None:
            row = conn.execute("""INSERT INTO device(serial_number,device_type_id,location_id,status,note)
                VALUES (%s,%s,%s,%s,%s) RETURNING device_id""",values).fetchone()
            device_id = row["device_id"]
        else:
            # Gleiche Zeilensperre wie bei Ausgabe: Statusänderungen sind atomar.
            row = conn.execute("SELECT device_id FROM device WHERE device_id=%s FOR UPDATE",(device_id,)).fetchone()
            if not row:
                raise HTTPException(404, "Gerät nicht gefunden")
            if data.status != "ready" and conn.execute(
                "SELECT 1 FROM assignment WHERE device_id=%s AND returned_at IS NULL",(device_id,)
            ).fetchone():
                raise HTTPException(409, "Ausgeliehenes Gerät zuerst zurückgeben")
            conn.execute("""UPDATE device SET serial_number=%s,device_type_id=%s,location_id=%s,
                status=%s,note=%s WHERE device_id=%s""",values+(device_id,))
    return device(device_id)

def delete_device(device_id):
    with get_conn() as conn:
        row = conn.execute("DELETE FROM device WHERE device_id=%s RETURNING device_id",(device_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Gerät nicht gefunden")

def assignments(active=False):
    with get_conn() as conn:
        return conn.execute(ASSIGNMENT_SELECT + (" WHERE a.returned_at IS NULL" if active else "")
            + " ORDER BY a.issued_at DESC,a.assignment_id DESC").fetchall()

def assignment(assignment_id):
    with get_conn() as conn:
        return conn.execute(ASSIGNMENT_SELECT+" WHERE a.assignment_id=%s",(assignment_id,)).fetchone()

def issue(data: AssignmentCreate):
    with get_conn() as conn:
        row = conn.execute("SELECT status FROM device WHERE device_id=%s FOR UPDATE",(data.device_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Gerät nicht gefunden")
        if row["status"] != "ready":
            raise HTTPException(409, "Gerät ist nicht ausleihbar")
        row = conn.execute("""INSERT INTO assignment(device_id,person_id,issued_at)
            VALUES (%s,%s,COALESCE(%s,now())) RETURNING assignment_id""",
            (data.device_id,data.person_id,data.issued_at)).fetchone()
    result = assignment(row["assignment_id"])
    publish_assignment("issued",result)
    return result

def return_assignment(assignment_id,data: AssignmentReturn):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM assignment WHERE assignment_id=%s FOR UPDATE",(assignment_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Ausleihe nicht gefunden")
        if row["returned_at"] is not None:
            raise HTTPException(409, "Ausleihe wurde bereits zurückgegeben")
        conn.execute("UPDATE assignment SET returned_at=COALESCE(%s,now()) WHERE assignment_id=%s",
            (data.returned_at,assignment_id))
    result = assignment(assignment_id)
    publish_assignment("returned",result)
    return result

def lookups():
    with get_conn() as conn:
        return {
            "device_types":conn.execute("SELECT * FROM device_type ORDER BY name").fetchall(),
            "locations":conn.execute("SELECT * FROM location ORDER BY name").fetchall(),
            "persons":conn.execute("SELECT * FROM person ORDER BY last_name,first_name").fetchall(),
        }
