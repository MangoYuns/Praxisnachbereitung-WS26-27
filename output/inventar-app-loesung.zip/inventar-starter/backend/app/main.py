from pathlib import Path
import psycopg
from fastapi import FastAPI, HTTPException, Query, Request, Response
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from . import services
from .db import get_conn
from .models import Assignment, AssignmentCreate, AssignmentReturn, Device, DeviceCreate
from .mqtt_integration import publish

app = FastAPI(title="Inventar-App",version="1.0.0")
templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))

@app.exception_handler(psycopg.IntegrityError)
def integrity_error(request: Request,exc: psycopg.IntegrityError):
    constraint = exc.diag.constraint_name
    if isinstance(exc,psycopg.errors.UniqueViolation):
        message = "Seriennummer existiert bereits" if constraint == "device_serial_number_key" else "Gerät ist bereits ausgeliehen"
        return JSONResponse(status_code=409,content={"detail":message})
    if isinstance(exc,psycopg.errors.ForeignKeyViolation):
        message = "Datensatz wird noch von Ausleihen verwendet" if request.method == "DELETE" else "Referenzierter Datensatz existiert nicht"
        return JSONResponse(status_code=409 if request.method == "DELETE" else 422,content={"detail":message})
    message = "Rückgabe darf nicht vor der Ausgabe liegen" if constraint == "assignment_return_time_check" else "Ungültige Daten"
    return JSONResponse(status_code=422,content={"detail":message})

@app.get("/health")
def health(response: Response):
    states = {"db":"ok","mqtt":"ok"}
    try:
        with get_conn() as conn:
            conn.execute("SELECT 1").fetchone()
    except Exception as exc:
        states["db"] = f"error:{type(exc).__name__}"
    try:
        publish("inventory/health","ok")
    except Exception as exc:
        states["mqtt"] = f"error:{type(exc).__name__}"
    ok = all(s == "ok" for s in states.values())
    response.status_code = 200 if ok else 503
    return {"status":"ok" if ok else "degraded",**states}

@app.get("/",include_in_schema=False)
def index():
    return RedirectResponse("/inventory",status_code=303)

@app.get("/inventory",response_class=HTMLResponse)
def inventory_page(request: Request):
    rows = services.devices()
    return templates.TemplateResponse(request=request,name="inventory.html",context={
        "title":"Inventarverwaltung","devices":rows,
        "available":[d for d in rows if d["availability"] == "frei"],
        "active":services.assignments(active=True),**services.lookups(),
    })

@app.get("/devices",response_model=list[Device],tags=["Geräte"])
def list_devices():
    return services.devices()

@app.get("/devices/{device_id}",response_model=Device,tags=["Geräte"])
def get_device(device_id: int):
    return services.device(device_id)

@app.post("/devices",response_model=Device,status_code=201,tags=["Geräte"])
def create_device(data: DeviceCreate):
    return services.save_device(data)

@app.put("/devices/{device_id}",response_model=Device,tags=["Geräte"])
def update_device(device_id: int,data: DeviceCreate):
    return services.save_device(data,device_id)

@app.delete("/devices/{device_id}",status_code=204,tags=["Geräte"])
def delete_device(device_id: int):
    services.delete_device(device_id)
    return Response(status_code=204)

@app.get("/assignments",response_model=list[Assignment],tags=["Ausleihen"])
def list_assignments():
    return services.assignments()

@app.get("/assignments/active",response_model=list[Assignment],tags=["Ausleihen"])
def active_assignments():
    return services.assignments(active=True)

@app.post("/assignments",response_model=Assignment,status_code=201,tags=["Ausleihen"])
def create_assignment(data: AssignmentCreate):
    return services.issue(data)

@app.post("/assignments/{assignment_id}/return",response_model=Assignment,tags=["Ausleihen"])
def return_assignment(assignment_id: int,data: AssignmentReturn = AssignmentReturn()):
    return services.return_assignment(assignment_id,data)

@app.post("/mqtt/publish",tags=["MQTT"])
def mqtt_publish(topic: str = Query(...,min_length=1),payload: str = Query(...)):
    if any(char in topic for char in ("#","+",chr(0))):
        raise HTTPException(422,"Publish-Topic darf keine Platzhalter enthalten")
    try:
        publish(topic,payload)
    except Exception as exc:
        raise HTTPException(503,"MQTT-Broker nicht erreichbar") from exc
    return {"ok":True,"topic":topic,"payload":payload}
