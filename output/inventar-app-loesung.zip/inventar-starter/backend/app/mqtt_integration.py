import json
import logging
import os
import paho.mqtt.client as mqtt

logger = logging.getLogger(__name__)

def publish(topic: str, payload: str):
    client = mqtt.Client()
    client.connect(os.getenv("MQTT_HOST", "mqtt"), int(os.getenv("MQTT_PORT", "1883")), 30)
    client.loop_start()
    try:
        info = client.publish(topic, payload, qos=1, retain=False)
        info.wait_for_publish(timeout=3)
        if not info.is_published():
            raise TimeoutError("MQTT-Nachricht wurde nicht bestätigt")
    finally:
        client.disconnect()
        client.loop_stop()

def publish_assignment(event: str, row: dict):
    # Erst nach dem DB-Commit senden. Fehlgeschlagene Vorgänge erzeugen kein Event.
    payload = {key: row[key] for key in ("assignment_id", "device_id", "person_id", "issued_at", "returned_at")}
    try:
        publish(f"inventory/assignments/{event}", json.dumps(payload, default=lambda d: d.isoformat()))
    except Exception:
        # Die Ausleihe ist bereits gespeichert; ein Broker-Ausfall macht sie nicht rückgängig.
        logger.exception("Ausleihe gespeichert, MQTT-Event %s fehlgeschlagen", event)
